<?php 
// Text
$_['text_title']                                = 'Доставка Justin';
$_['text_description']                          = 'Доставка Justin';
$_['text_select_departments']                   = 'Виберіть відділенняе';
$_['text_select_all_departments']               = 'Вибрати із всіх відділень';

?>