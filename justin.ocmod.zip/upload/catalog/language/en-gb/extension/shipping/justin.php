<?php 
// Text
$_['text_title']                            = 'Delivery Justin';
$_['text_description']                      = 'Delivery Justin';
$_['text_select_departments']               = 'Select a department';
$_['text_select_all_departments']           = 'Select from all departments';

?>