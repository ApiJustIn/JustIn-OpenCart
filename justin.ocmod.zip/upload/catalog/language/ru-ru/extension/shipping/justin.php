<?php 
// Text
$_['text_title']                                = 'Доставка Justin';
$_['text_description']                          = 'Доставка Justin';
$_['text_select_departments']                   = 'Выберите отделение';
$_['text_select_all_departments']               = 'Выбрать из всех отделений';

?>